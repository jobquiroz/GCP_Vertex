import setuptools

setuptools.setup(

    install_requires=[

        'tensorflow_datasets',

    ],

    packages=setuptools.find_packages())
